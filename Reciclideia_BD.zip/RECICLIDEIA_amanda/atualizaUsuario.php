<?php
    header('Content-Type: application/json');
    header('Character-Encoding: utf-8');

    $json_entrada = json_decode(file_get_contents('php://input'));

    //definindo conexão com o banco de dados
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=reciclideia;port=3306;charset=utf8','root', 'ValenteGeorge75');

    //preparando o SQL para atualizar 
    $sql = "UPDATE INTO login(usuario, email) VALUES (:usuario, :email)";

    $statement = $pdo->prepare($sqlinsert);
          $statement->bindValue(':nome',$nome, PDO::PARAM_STR);
          $statement ->bindValue(':usuario',$usuario, PDO::PARAM_STR);
          $statement->bindValue(':email',$email, PDO::PARAM_STR);
          $statement->bindValue(':senha',$senha, PDO::PARAM_STR);
          $statement->execute();
        
          if($statement->rowCount() > 0){
            echo "sim";
          }
          else{
            echo "nao";
          }
?>
    

?>