package com.example.reciclideia

data class Ideias(var titleimage : Int, var cabecalho : String)
