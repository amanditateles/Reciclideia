package com.example.reciclideia

import android.content.Intent
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset

class Cadastro : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)


        val edtNome = findViewById<EditText>(R.id.edt_nome)
        val edtEmail = findViewById<EditText>(R.id.edt_email)
        val edtUsuario = findViewById<EditText>(R.id.edt_usuario)
        val edtSenha = findViewById<EditText>(R.id.edt_senha)
        val buttonRealizarCadastro = findViewById<Button>(R.id.buttonRealizarCadastro)

        buttonRealizarCadastro.setOnClickListener {
            var nome = edtNome.text.toString()
            var email = edtEmail.text.toString()
            var usuario = edtUsuario.text.toString()
            var senha = edtSenha.text.toString()

            if (nome.isNotEmpty() && email.isNotEmpty() && usuario.isNotEmpty() && senha.isNotEmpty()) {
                //cria uma instância da classe que fará a requisição
                var validaUsuario = ValidaUsuario()
                //invoca a execução passando o usuário e a senha como parâmetro
                validaUsuario.execute(nome, email, usuario, senha)
            }

        }
    }

    //definição de uma classe que fará o que
    inner class ValidaUsuario : AsyncTask<String?, Void, Usuario?>() {
        override fun doInBackground(vararg params: String?): Usuario? {
            //pega os parametros nome, email, usuario e senha
            var nome = params[0] as String
            var email = params[1] as String
            var usuario = params[2] as String
            var senha = params[3] as String
            //cria um JSOn
            var jsonUsuario = JSONObject()
            jsonUsuario.put("nome", nome)
            jsonUsuario.put("email", email)
            jsonUsuario.put("usuario", usuario)
            jsonUsuario.put("senha", senha)


            try {
                val url = URL("http://192.168.1.75:8080/reciclideia-APP/verificaUsuario.php")
                val conexao = (url.openConnection() as HttpURLConnection)

                conexao.readTimeout = 15000
                conexao.connectTimeout = 15000
                conexao.requestMethod = "POST"
                conexao.doInput = true
                conexao.doOutput = true
                conexao.setRequestProperty("Content-Type", "application/json")
                conexao.connect()
                //após a conexão
                var outputStream: OutputStream = conexao.outputStream
                outputStream.write(jsonUsuario.toString().encodeToByteArray())
                //finaliza a conexao
                outputStream.flush()
                outputStream.close()
                //após o envio de dados
                val responseCode = conexao.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val inputStream = conexao.inputStream
                    //chama o método que transformará os byte em string
                    //armazena a string na variável resultado
                    var resultado = streamToString(inputStream)
                    //criar um objeto JSON a partir da entrada
                    val json = JSONObject(resultado)
                    //pega o id do objeto JSON
                    var id = json.getInt("id")
                    return Usuario(id,nome,email, usuario,)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return null
        }

        //função que converte os byte para string
        private fun streamToString(inputStream: InputStream): String {
            //criaçao de variáveis para pegar dados e carregar os dados na memória
            val buffer = ByteArray(1024)
            val dados = ByteArrayOutputStream()
            //variável para verificar quantos byte foram lidos na última tentativa
            var bytesRead: Int
            //estrutura de repetição para ler do input em grupos de 1024 bytes
            while (true) {
                //ler bytes do input para o buffer e pega a quantidade de elementos
                bytesRead = inputStream.read(buffer)
                //decisão para parar significa
                if (bytesRead == -1) break
                dados.write(buffer, 0, bytesRead)
            }
            return String(dados.toByteArray(), Charset.forName("UTF-8"))
        }

    }
}
