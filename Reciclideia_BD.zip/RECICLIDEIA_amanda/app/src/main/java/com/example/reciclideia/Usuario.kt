package com.example.reciclideia

data class Usuario(
    var id: Int,
    var nome: String?,
    var email: String?,
    var usuario: String?,
    var senha: String?
){
    //criação de um construtor secundário
    constructor(id: Int, nome: String, email: String, usuario: String) : this(id,nome, email, usuario,null)
}
