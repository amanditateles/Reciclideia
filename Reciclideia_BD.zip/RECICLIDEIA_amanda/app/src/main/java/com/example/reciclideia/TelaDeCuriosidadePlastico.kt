package com.example.reciclideia

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class TelaDeCuriosidadePlastico : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_de_curiosidade_plastico)
    }
}