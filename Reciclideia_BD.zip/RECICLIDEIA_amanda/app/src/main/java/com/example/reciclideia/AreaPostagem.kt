package com.example.reciclideia

import android.graphics.Bitmap
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import java.net.HttpURLConnection
import java.net.URL

class AreaPostagem : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_area_postagem)
    }

    inner class UsuariosDownloadTask: AsyncTask<Void, Void, List<Usuario>?>() {...}
    inner class PublicUsuarioDownloadTask: AsyncTask<Int, Void, Bitmap?>() {...}

    var i: Int = -1
    override fun doInBackground(vararg params: Int?): Bitmap? {
        this.i = params[0] as Int
        val id = UsuarioController.getFuncionario(this.i).id
        try{
            val url = URL("http://192.168.1.75:8080/reciclideia-APP/carregaPost.php?id="+id.toString())
            val conexao = (url.openConnection() as HttpURLConnection)
            conexao.readTimeout = 25000
            conexao.connectTimeout = 15000
            conexao.requestMethod = "GET"
            conexao.doInput = true
            conexao.doOutput = false
            conexao.connect()
            val respondeCode = conexao.responseCode
            if(respondeCode == HttpURLConnection.HTTP_OK) {
                val  inputStream = conexao.inputStream
                return BitMapFactory.decodeStream(inputStream)
            }
        } catch(e: Exception) {
            e.printStackTrace()
        }
        return null
    }
}

