package com.example.reciclideia

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtUsuario = findViewById<EditText>(R.id.edt_usuario)
        val edtSenha = findViewById<EditText>(R.id.edt_senha)
        val btnEntrar = findViewById<Button>(R.id.btn_entrar)

        btnEntrar.setOnClickListener{
            var usuario = edtUsuario.text.toString()
            var senha = edtSenha.text.toString()

            if(usuario.isNotEmpty() && senha.isNotEmpty()){
            //cria uma instância da classe que fará a requisição
            var validaUsuario = ValidaUsuario()
            //invoca a execução passando o usuário e a senha como parâmetro
            validaUsuario.execute(usuario,senha)
        }
        }

        val buttonCriarConta = findViewById<Button>(R.id.buttonCriarConta)
        buttonCriarConta.setOnClickListener{
            openActivity()
        }
        val buttonEsqueciMinhaSenha = findViewById<Button>(R.id.buttonEsqueciMinhaSenha)
        buttonEsqueciMinhaSenha.setOnClickListener{
            openNewActivity()
        }

    }

    //definição de uma classe que fará o que
    inner class ValidaUsuario : AsyncTask<String?, Void, Usuario?>() {
        override fun doInBackground(vararg params: String?): Usuario? {
            //pega os parametros usuario e senha
            var usuario = params[0] as String
            var senha = params[1] as String
            //cria um JSOn
            var jsonUsuario = JSONObject()
            jsonUsuario.put("usuario", usuario)
            jsonUsuario.put("senha", senha)

            try {
                val url = URL("http://192.168.1.75:8080/reciclideia-APP/verificaUsuario.php")
                val conexao = (url.openConnection() as HttpURLConnection)

                conexao.readTimeout = 15000
                conexao.connectTimeout = 15000
                conexao.requestMethod = "POST"
                conexao.doInput = true
                conexao.doOutput = true
                conexao.setRequestProperty("Content-Type", "application/json")
                conexao.connect()
                //após a conexão
                var outputStream: OutputStream = conexao.outputStream
                outputStream.write(jsonUsuario.toString().encodeToByteArray())
                //finaliza a conexao
                outputStream.flush()
                outputStream.close()
                //após o envio de dados
                val responseCode = conexao.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val inputStream = conexao.inputStream
                    //chama o método que transformará os byte em string
                    //armazena a string na variável resultado
                    var resultado = streamToString(inputStream)
                    //criar um objeto JSON a partir da entrada
                    val json = JSONObject(resultado)
                    //pega o id do objeto JSON
                    var id = json.getInt("id")
                    return Usuario(id, usuario)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return null
            }

        //função que converte os byte para string
        private fun streamToString(inputStream: InputStream): String {
            //criaçao de variáveis para pegar dados e carregar os dados na memória
            val buffer = ByteArray(1024)
            val dados = ByteArrayOutputStream()
            //variável para verificar quantos byte foram lidos na última tentativa
            var bytesRead: Int
            //estrutura de repetição para ler do input em grupos de 1024 bytes
            while (true) {
                //ler bytes do input para o buffer e pega a quantidade de elementos
                bytesRead = inputStream.read(buffer)
                //decisão para parar significa
                if (bytesRead == -1) break
                dados.write(buffer, 0, bytesRead)
            }
            return String(dados.toByteArray(), Charset.forName("UTF-8"))
        }

        //funcao a ser executada apos ter recebido as informações do servidor ja tratados
        override fun onPostExecute(usuario: Usuario?) {
            super.onPostExecute(usuario)

            //verificação se o usuario retornado foi nao nulo
            if (usuario!=null) {
                //cria uma intent para chamar a proxima tela
                val intent = Intent(applicationContext, TelaInicial::class.java)

                //define os paranmetros para a proxima activity
                //pode ser implementado, alternativamnete, a passagem do objeto usuario inteiro,
                //porem tem necessidades de implemenatar mais alguns recursos
                intent.putExtra("id",usuario.id)
                intent.putExtra("usuario",usuario.usuario)

                //inicia a activity da tela principal o home
                startActivity(intent)
                //encerra a activity de login
                finish()
            }
        }

        }

    private fun openActivity(){
        val intent = Intent(this, Cadastro::class.java)
        startActivity(intent)
    }
    private fun openNewActivity(){
        val intent = Intent(this, RedefinirSenha::class.java)
        startActivity(intent)
    }

}






