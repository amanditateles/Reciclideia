<?php
    header('Content-Type: application/json');
    header('Character-Encoding: utf-8');

    $json_entrada = json_decode(file_get_contents('php://input'));
    $usuario = $json_entrada->{'usuario'};
    $senha = $json_entrada->{'senha'};

    //definindo conexão com o banco de dados
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=reciclideia;port=3306;charset=utf8','root', 'ValenteGeorge75');
    //preparando o sql 
    $sql = 'SELECT id FROM login where usuario=:usuario and senha=md5(:senha)';
    $statement = $pdo->prepare($sql);
    $statement->bindValue(':usuario', $usuario, PDO::PARAM_STR);
    $statement->bindValue(':senha', $senha, PDO::PARAM_STR);
    $statement->execute();

    $usuario = array();
    if($result = $statement->fetch(PDO::FETCH_ASSOC)) {
        $usuario = (object) $result;

    }
    $json = json_encode($id);
    echo $json;
?>